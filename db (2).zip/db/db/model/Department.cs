﻿using System.ComponentModel.DataAnnotations;
using Assign.model;

public class Department
{
    [Key]
    public int Depid { get; set; }

    [Required]
    [StringLength(50)]
    public string Depname { get; set; }
    public List<Faculty> Faculties { get; set; } = new List<Faculty>();
}
