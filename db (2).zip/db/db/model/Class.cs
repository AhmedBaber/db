﻿using Assign.model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

public class Class
{
    [Key]
    public int Cid { get; set; }

    [Required]
    [StringLength(50)]
    public string Name { get; set; }

    [Required]
    [StringLength(50)]
    public string RoomNumber { get; set; }

    public int Fid { get; set; }

    // Navigation property for the enrolled relationship
    public IList<Enrolled> Enrollments { get; set; }
    public Faculty Faculty { get; set; }
    public IList<Student> Students { get; set; }
}
