﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Assign.model;

public class Faculty
{
    [Key]
    public int Fid { get; set; }

    [Required]
    [StringLength(50)]
    public string Fname { get; set; }

    public int Depid { get; set; }

    [Required]
    [StringLength(50)]
    public string FStanding { get; set; }

    // Navigation property for the class relationship
    public List<Class> Classestaught { get; set; }=new List<Class>();
    public Department Department { get; set; }
}