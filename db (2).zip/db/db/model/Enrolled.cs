﻿using Assign.model;
using System.ComponentModel.DataAnnotations;

public class Enrolled
{
    [Key]
    public int Eid { get; set; }

    public int Sid { get; set; } // Foreign key for the Student entity

    public int Cid { get; set; } // Foreign key for the Class entity

    // Navigation properties for many-to-many relationship
    public Student Student { get; set; }

    public Class Class { get; set; }
}
