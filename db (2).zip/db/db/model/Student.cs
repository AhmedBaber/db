﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Assign.model;


public class Student
{
    [Key]
    public int Sid { get; set; }

    [Required]
    [StringLength(50)]
    public string Sname { get; set; }

    [Required]
    [StringLength(50)]
    public string Major { get; set; }

    [Required]
    [StringLength(50)]
    public string Standing { get; set; }

    // Navigation property for the enrolled relationship
    public IList<Enrolled> Enrollments { get; set; }
    public IList<Class> Class { get; set; }
}