﻿
using Microsoft.EntityFrameworkCore;

namespace Assign.model
{
    public class AppClass : DbContext
    {
        public AppClass(DbContextOptions<AppClass> options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Faculty> Faculties { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Enrolled> Enrollments { get; set; }
        public DbSet<Department> Departments { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define relationships
            modelBuilder.Entity<Enrolled>()
                .HasKey(e => e.Eid);

            modelBuilder.Entity<Enrolled>()
                .HasOne(e => e.Student)
                .WithMany(s => s.Enrollments)
                .HasForeignKey(e => e.Sid);

            modelBuilder.Entity<Enrolled>()
                .HasOne(e => e.Class)
                .WithMany(c => c.Enrollments)
                .HasForeignKey(e => e.Cid);

            modelBuilder.Entity<Class>()
                .HasOne(c => c.Faculty)
                .WithMany(f => f.Classestaught)
                .HasForeignKey(c => c.Fid);

            modelBuilder.Entity<Faculty>()
                .HasMany(f => f.Classestaught)
                .WithOne(c => c.Faculty)
                .HasForeignKey(c => c.Fid);

            modelBuilder.Entity<Student>()
                .HasMany(s => s.Enrollments)
                .WithOne(e => e.Student)
                .HasForeignKey(e => e.Sid);

            modelBuilder.Entity<Department>()
                .HasKey(d => d.Depid);

            modelBuilder.Entity<Faculty>()
        .HasOne(f => f.Department)
        .WithMany(d => d.Faculties)
        .HasForeignKey(f => f.Depid);
        }
    }
}



